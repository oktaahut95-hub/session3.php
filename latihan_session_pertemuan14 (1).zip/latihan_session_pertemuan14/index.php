<?php
// Arahkan pengguna ke halaman login.
header("Location: session1.php");
exit;
