<?php
session_start();

if (isset($_SESSION['login'])) {
    // Menghapus data session dan mengakhiri session.
    $_SESSION = [];
    session_destroy();
    $message = "Anda sudah berhasil logout.";
} else {
    $message = "Anda belum login atau session sudah berakhir.";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout</title>
    <style>
        body { font-family:Arial,sans-serif; background:#f3f4f6; display:grid; place-items:center; min-height:100vh; margin:0; }
        .card { background:white; padding:30px; border-radius:12px; width:min(520px, calc(100% - 40px)); box-shadow:0 4px 18px #0001; }
        a { color:#2563eb; }
    </style>
</head>
<body>
<div class="card">
    <h1><?= htmlspecialchars($message) ?></h1>
    <p>Anda sekarang tidak dapat mengakses halaman session2.php sebelum login kembali.</p>
    <a href="session1.php">Login kembali</a>
</div>
</body>
</html>
