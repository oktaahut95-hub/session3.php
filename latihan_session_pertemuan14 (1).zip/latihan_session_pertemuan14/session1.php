<?php
session_start();

if (isset($_POST['Login'])) {
    $user = trim($_POST['user'] ?? '');
    $pass = $_POST['pass'] ?? '';

    // Pemeriksaan username dan password
    if ($user === "rahadian" && $pass === "123") {
        $_SESSION['login'] = $user;
        header("Location: session2.php");
        exit;
    } else {
        $error = "Username atau password salah!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body { font-family: Arial, sans-serif; background:#f3f4f6; display:grid; place-items:center; min-height:100vh; margin:0; }
        .card { background:white; padding:28px; border-radius:12px; width:min(340px, calc(100% - 40px)); box-shadow:0 4px 18px #0001; }
        input { box-sizing:border-box; width:100%; padding:10px; margin:8px 0 14px; }
        button { width:100%; padding:11px; background:#2563eb; color:white; border:0; border-radius:6px; cursor:pointer; }
        .error { color:#b91c1c; }
    </style>
</head>
<body>
<div class="card">
    <h2>Login Here</h2>
    <?php if (isset($error)) echo '<p class="error">' . htmlspecialchars($error) . '</p>'; ?>
    <form method="post" action="">
        <label>Username</label>
        <input type="text" name="user" required>
        <label>Password</label>
        <input type="password" name="pass" required>
        <button type="submit" name="Login" value="1">Log In</button>
    </form>
</div>
</body>
</html>
