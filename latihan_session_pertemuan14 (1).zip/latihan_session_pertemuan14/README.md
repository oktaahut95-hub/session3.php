# Latihan Session - Pemrograman Web 2

Project ini berisi latihan Session PHP berdasarkan materi Pertemuan 14 (BAB IX).

## File
- `session1.php`: membuat session melalui proses login.
- `session2.php`: memeriksa session sebelum menampilkan halaman terbatas.
- `session3.php`: menghapus session saat logout.
- `index.php`: mengarahkan pengguna ke halaman login.

## Cara menjalankan
1. Pastikan PHP dan web server (misalnya XAMPP) sudah terpasang.
2. Salin folder project ke dalam folder `htdocs`.
3. Jalankan Apache melalui XAMPP.
4. Buka `http://localhost/latihan_session_pertemuan14/`.

## Akun latihan
- Username: `rahadian`
- Password: `123`

Catatan: akun di atas mengikuti contoh pada materi. Ini hanya untuk latihan, bukan autentikasi produksi.
