<?php
session_start();

// Halaman hanya dapat dibuka jika session login tersedia.
if (!isset($_SESSION['login'])) {
    header("Location: session1.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pemeriksaan Session</title>
    <style>
        body { font-family:Arial,sans-serif; background:#f3f4f6; display:grid; place-items:center; min-height:100vh; margin:0; }
        .card { background:white; padding:30px; border-radius:12px; width:min(520px, calc(100% - 40px)); box-shadow:0 4px 18px #0001; }
        a { color:#2563eb; }
    </style>
</head>
<body>
<div class="card">
    <h1>Selamat Datang, <?= htmlspecialchars($_SESSION['login']) ?>!</h1>
    <h3>Halaman ini hanya bisa diakses jika Anda sudah login.</h3>
    <p><a href="session3.php">Logout</a></p>
</div>
</body>
</html>
